package com.ruoyi.index.domain;

/**
 * 其他栏目实体类
 *
 * @author Alex McAvoy
 * @version 1.0
 * @date 2023/10/1 22:51
 **/
public class IndexOtherColumns {
}
