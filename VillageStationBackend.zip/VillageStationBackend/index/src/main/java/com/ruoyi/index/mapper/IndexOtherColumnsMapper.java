package com.ruoyi.index.mapper;

/**
 * 其他栏目mapper
 *
 * @author Alex McAvoy
 * @version 1.0
 * @date 2023/10/1 22:58
 **/
public interface IndexOtherColumnsMapper {
}
