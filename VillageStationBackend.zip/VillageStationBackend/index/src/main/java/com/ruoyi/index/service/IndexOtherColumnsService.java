package com.ruoyi.index.service;

/**
 * 其他栏目service
 *
 * @author Alex McAvoy
 * @version 1.0
 * @date 2023/10/1 22:58
 **/
public interface IndexOtherColumnsService {
}
