package com.ruoyi.index.service.impl;

/**
 * 其他栏目service实现类
 *
 * @author Alex McAvoy
 * @version 1.0
 * @date 2023/10/1 22:59
 **/
public class IndexOtherColumnsServiceImpl {
}
