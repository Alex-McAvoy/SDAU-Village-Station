package com.ruoyi.web.controller.index;

/**
 * 新闻发布控制器
 *
 * @author Alex McAvoy
 * @version 1.0
 * @date 2023/10/1 22:45
 **/
public class IndexNewsController {
}
